import { db } from "../db/client.js";
import { tokenLedger } from "../db/schema.js";
import { eq, sql } from "drizzle-orm";

export async function addTokens(userId: string, delta: number, reason: string, meta: any = {}) {
  await db.insert(tokenLedger).values({ userId, delta, reason, meta });
}

export async function getTokenBalance(userId: string): Promise<number> {
  const rows = await db.select({
    balance: sql<number>`coalesce(sum(${tokenLedger.delta}), 0)`
  }).from(tokenLedger).where(eq(tokenLedger.userId, userId));
  return rows[0]?.balance ?? 0;
}

export async function getRecentLedger(userId: string, limit = 50) {
  return db.select().from(tokenLedger)
    .where(eq(tokenLedger.userId, userId))
    .orderBy(sql`${tokenLedger.createdAt} desc`)
    .limit(limit);
}
