import { redis } from "../lib/redis.js";

const DAILY_KEY = "lb:daily";
const WEEKLY_KEY = "lb:weekly";

export async function incrDaily(userId: string, delta: number) {
  if (delta === 0) return;
  await redis.zincrby(DAILY_KEY, delta, userId);
  await redis.expire(DAILY_KEY, 60 * 60 * 24 * 2);
}

export async function incrWeekly(userId: string, delta: number) {
  if (delta === 0) return;
  await redis.zincrby(WEEKLY_KEY, delta, userId);
  await redis.expire(WEEKLY_KEY, 60 * 60 * 24 * 8);
}

export async function topDaily(limit = 50) {
  const arr = await redis.zrevrange(DAILY_KEY, 0, limit - 1, "WITHSCORES");
  return toPairs(arr);
}

export async function topWeekly(limit = 50) {
  const arr = await redis.zrevrange(WEEKLY_KEY, 0, limit - 1, "WITHSCORES");
  return toPairs(arr);
}

function toPairs(arr: string[]) {
  const out: { userId: string; score: number }[] = [];
  for (let i = 0; i < arr.length; i += 2) {
    out.push({ userId: arr[i], score: Number(arr[i + 1] ?? 0) });
  }
  return out;
}
