import { db } from "../db/client.js";
import { gameRounds } from "../db/schema.js";
import { fairFloat, newServerSeed, sha256Hex } from "../lib/provablyFair.js";
import { addTokens, getTokenBalance } from "./tokens.js";
import { incrDaily, incrWeekly } from "./leaderboard.js";

const REDS = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);

function rouletteColor(n: number): "red" | "black" | "green" {
  if (n === 0) return "green";
  return REDS.has(n) ? "red" : "black";
}

export async function playSlots(userId: string, wager: number, clientSeed: string, nonce: number) {
  const balance = await getTokenBalance(userId);
  if (wager <= 0 || wager > 100000) throw new Error("invalid_wager");
  if (balance < wager) throw new Error("insufficient_tokens");

  const serverSeed = newServerSeed();
  const serverSeedHash = sha256Hex(serverSeed);

  const r1 = Math.floor(fairFloat(serverSeed, clientSeed, nonce) * 10);
  const r2 = Math.floor(fairFloat(serverSeed, clientSeed, nonce + 1) * 10);
  const r3 = Math.floor(fairFloat(serverSeed, clientSeed, nonce + 2) * 10);
  const reels = [r1, r2, r3];

  let mult = 0;
  if (r1 === r2 && r2 === r3) mult = (r1 === 7 ? 10 : 5);
  else if (r1 === r2 || r2 === r3 || r1 === r3) mult = 2;

  const payout = Math.floor(wager * mult);
  const net = payout - wager;

  await addTokens(userId, -wager, "slot_spin", { wager, serverSeedHash, clientSeed, nonce });
  if (payout > 0) await addTokens(userId, payout, "slot_spin_payout", { payout });

  const inserted = await db.insert(gameRounds).values({
    userId,
    game: "slots",
    wager,
    payout,
    clientSeed,
    serverSeedHash,
    serverSeedRevealed: serverSeed,
    nonce,
    result: { reels, payoutMultiplier: mult }
  }).returning({ id: gameRounds.id });

  await incrDaily(userId, net);
  await incrWeekly(userId, net);

  return { roundId: inserted[0].id, serverSeedHash, result: { reels, payoutMultiplier: mult, payout } };
}

export async function playRoulette(
  userId: string,
  wager: number,
  bet: { type: "color"; value: "red" | "black" } | { type: "number"; value: number },
  clientSeed: string,
  nonce: number
) {
  const balance = await getTokenBalance(userId);
  if (wager <= 0 || wager > 100000) throw new Error("invalid_wager");
  if (balance < wager) throw new Error("insufficient_tokens");

  const serverSeed = newServerSeed();
  const serverSeedHash = sha256Hex(serverSeed);

  const n = Math.floor(fairFloat(serverSeed, clientSeed, nonce) * 37);
  const color = rouletteColor(n);

  let win = false;
  let mult = 0;

  if (bet.type === "color") {
    win = (color === bet.value);
    mult = win ? 2 : 0;
  } else {
    win = (n === bet.value);
    mult = win ? 36 : 0;
  }

  const payout = Math.floor(wager * mult);
  const net = payout - wager;

  await addTokens(userId, -wager, "roulette_spin", { wager, bet, serverSeedHash, clientSeed, nonce });
  if (payout > 0) await addTokens(userId, payout, "roulette_spin_payout", { payout });

  const inserted = await db.insert(gameRounds).values({
    userId,
    game: "roulette",
    wager,
    payout,
    clientSeed,
    serverSeedHash,
    serverSeedRevealed: serverSeed,
    nonce,
    result: { number: n, color, bet, win, payoutMultiplier: mult }
  }).returning({ id: gameRounds.id });

  await incrDaily(userId, net);
  await incrWeekly(userId, net);

  return { roundId: inserted[0].id, serverSeedHash, result: { number: n, color, win, payout } };
}
