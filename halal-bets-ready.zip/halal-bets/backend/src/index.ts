import "dotenv/config";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import passport from "passport";

import authRoutes from "./routes/auth.js";
import meRoutes from "./routes/me.js";
import walletRoutes from "./routes/wallet.js";
import dailyBonusRoutes from "./routes/dailyBonus.js";
import gamesRoutes from "./routes/games.js";
import leaderboardRoutes from "./routes/leaderboard.js";
import prizesRoutes from "./routes/prizes.js";

const app = express();

app.use(morgan("dev"));
app.use(cors({
  origin: process.env.FRONTEND_ORIGIN,
  credentials: true,
}));
app.use(express.json());
app.use(cookieParser());
app.use(passport.initialize());

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use("/auth", authRoutes);
app.use("/", meRoutes);
app.use("/", walletRoutes);
app.use("/", dailyBonusRoutes);
app.use("/", gamesRoutes);
app.use("/", leaderboardRoutes);
app.use("/", prizesRoutes);

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => {
  console.log(`Backend listening on http://localhost:${port}`);
});
