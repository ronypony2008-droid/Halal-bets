import { pgTable, uuid, text, timestamp, bigint, integer, numeric, jsonb, uniqueIndex } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").unique(),
  displayName: text("display_name"),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const oauthAccounts = pgTable("oauth_accounts", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  provider: text("provider").notNull(), // 'google'
  providerAccountId: text("provider_account_id").notNull(), // google sub
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  providerUniq: uniqueIndex("oauth_provider_account_uniq").on(t.provider, t.providerAccountId),
}));

export const tokenLedger = pgTable("token_ledger", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  delta: bigint("delta", { mode: "number" }).notNull(),
  reason: text("reason").notNull(),
  meta: jsonb("meta").notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const gameRounds = pgTable("game_rounds", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  game: text("game").notNull(), // 'slots' | 'roulette'
  wager: bigint("wager", { mode: "number" }).notNull(),
  payout: bigint("payout", { mode: "number" }).notNull(),
  clientSeed: text("client_seed").notNull(),
  serverSeedHash: text("server_seed_hash").notNull(),
  serverSeedRevealed: text("server_seed_revealed"),
  nonce: integer("nonce").notNull(),
  result: jsonb("result").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const prizeCampaigns = pgTable("prize_campaigns", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  prizePoolUsd: numeric("prize_pool_usd", { precision: 12, scale: 2 }).notNull(),
  rules: text("rules").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const prizeWinners = pgTable("prize_winners", {
  id: uuid("id").defaultRandom().primaryKey(),
  campaignId: uuid("campaign_id").notNull().references(() => prizeCampaigns.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  rank: integer("rank").notNull(),
  prizeUsd: numeric("prize_usd", { precision: 12, scale: 2 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
