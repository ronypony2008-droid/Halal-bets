import "dotenv/config";
import fs from "fs";
import path from "path";
import { pool } from "./client.js";

async function main() {
  const sqlPath = path.join(process.cwd(), "src", "db", "migrations", "0000_init.sql");
  const sql = fs.readFileSync(sqlPath, "utf-8");
  await pool.query(sql);
  await pool.end();
  console.log("Migration applied");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
