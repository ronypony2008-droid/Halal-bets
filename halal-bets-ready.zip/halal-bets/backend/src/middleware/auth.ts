import type { Request, Response, NextFunction } from "express";
import { sessionCookieName, verifySession } from "../lib/session.js";

export function requireUser(req: Request, res: Response, next: NextFunction) {
  const token = (req as any).cookies?.[sessionCookieName];
  if (!token) return res.status(401).json({ error: "unauthorized" });

  const session = verifySession(token, process.env.COOKIE_SECRET!);
  if (!session?.userId) return res.status(401).json({ error: "unauthorized" });

  (req as any).user = session;
  next();
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user;
  const adminEmail = process.env.ADMIN_EMAIL;
  if (!adminEmail) return res.status(500).json({ error: "admin_not_configured" });
  if (user?.email !== adminEmail) return res.status(403).json({ error: "forbidden" });
  next();
}
