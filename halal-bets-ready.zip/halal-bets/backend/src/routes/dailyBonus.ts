import { Router } from "express";
import { requireUser } from "../middleware/auth.js";
import { addTokens } from "../services/tokens.js";
import { redis } from "../lib/redis.js";

const router = Router();

router.post("/daily-bonus", requireUser, async (req, res) => {
  const userId = (req as any).user.userId as string;
  const key = `daily_bonus:${userId}`;

  const ok = await redis.set(key, "1", "NX", "EX", 60 * 60 * 24);
  if (!ok) return res.status(429).json({ error: "already_claimed" });

  const amount = 5000;
  await addTokens(userId, amount, "daily_bonus", { amount });
  res.json({ ok: true, amount });
});

export default router;
