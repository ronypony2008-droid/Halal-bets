import { Router } from "express";
import { z } from "zod";
import { requireUser } from "../middleware/auth.js";
import { playRoulette, playSlots } from "../services/games.js";
import { db } from "../db/client.js";
import { gameRounds } from "../db/schema.js";
import { eq } from "drizzle-orm";

const router = Router();

const slotsSchema = z.object({
  wager: z.number().int().positive(),
  clientSeed: z.string().min(1).max(64),
  nonce: z.number().int().nonnegative(),
});

router.post("/games/slots/spin", requireUser, async (req, res) => {
  const userId = (req as any).user.userId as string;
  const parsed = slotsSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "bad_request", details: parsed.error.flatten() });

  try {
    const out = await playSlots(userId, parsed.data.wager, parsed.data.clientSeed, parsed.data.nonce);
    res.json(out);
  } catch (e: any) {
    res.status(400).json({ error: e.message ?? "failed" });
  }
});

const rouletteSchema = z.object({
  wager: z.number().int().positive(),
  clientSeed: z.string().min(1).max(64),
  nonce: z.number().int().nonnegative(),
  bet: z.union([
    z.object({ type: z.literal("color"), value: z.enum(["red", "black"]) }),
    z.object({ type: z.literal("number"), value: z.number().int().min(0).max(36) }),
  ])
});

router.post("/games/roulette/spin", requireUser, async (req, res) => {
  const userId = (req as any).user.userId as string;
  const parsed = rouletteSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "bad_request", details: parsed.error.flatten() });

  try {
    const out = await playRoulette(userId, parsed.data.wager, parsed.data.bet as any, parsed.data.clientSeed, parsed.data.nonce);
    res.json(out);
  } catch (e: any) {
    res.status(400).json({ error: e.message ?? "failed" });
  }
});

router.get("/games/round/:id", requireUser, async (req, res) => {
  const id = req.params.id;
  const rows = await db.select().from(gameRounds).where(eq(gameRounds.id, id)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "not_found" });
  res.json({ round: rows[0] });
});

export default router;
