import { Router } from "express";
import { requireUser } from "../middleware/auth.js";
import { getTokenBalance, getRecentLedger } from "../services/tokens.js";

const router = Router();

router.get("/wallet", requireUser, async (req, res) => {
  const userId = (req as any).user.userId as string;
  const balance = await getTokenBalance(userId);
  const ledger = await getRecentLedger(userId, 50);
  res.json({ balance, ledger });
});

export default router;
