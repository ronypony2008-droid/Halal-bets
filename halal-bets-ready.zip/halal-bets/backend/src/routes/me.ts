import { Router } from "express";
import { requireUser } from "../middleware/auth.js";

const router = Router();

router.get("/me", requireUser, async (req, res) => {
  const sess = (req as any).user;
  res.json({ user: sess });
});

export default router;
