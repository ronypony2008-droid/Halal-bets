import { Router } from "express";
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { db } from "../db/client.js";
import { oauthAccounts, users } from "../db/schema.js";
import { and, eq } from "drizzle-orm";
import { sessionCookieName, signSession } from "../lib/session.js";

const router = Router();

passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID!,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
  callbackURL: "http://localhost:4000/auth/google/callback",
}, async (_accessToken, _refreshToken, profile, done) => {
  try {
    const googleSub = profile.id;
    const email = profile.emails?.[0]?.value ?? null;
    const displayName = profile.displayName ?? null;
    const avatarUrl = profile.photos?.[0]?.value ?? null;

    const existing = await db.select().from(oauthAccounts)
      .where(and(eq(oauthAccounts.provider, "google"), eq(oauthAccounts.providerAccountId, googleSub)))
      .limit(1);

    let userId: string;

    if (existing.length) {
      userId = existing[0].userId;
      await db.update(users).set({
        email: email ?? undefined,
        displayName: displayName ?? undefined,
        avatarUrl: avatarUrl ?? undefined,
      }).where(eq(users.id, userId));
    } else {
      const created = await db.insert(users).values({
        email: email ?? undefined,
        displayName: displayName ?? undefined,
        avatarUrl: avatarUrl ?? undefined,
      }).returning({ id: users.id });

      userId = created[0].id;

      await db.insert(oauthAccounts).values({
        userId,
        provider: "google",
        providerAccountId: googleSub,
      });
    }

    return done(null, { userId, email, displayName, avatarUrl });
  } catch (e) {
    return done(e as any);
  }
}));

router.get("/google", passport.authenticate("google", { scope: ["profile", "email"] }));

router.get("/google/callback",
  passport.authenticate("google", { session: false, failureRedirect: "/auth/failed" }),
  (req, res) => {
    const u = req.user as any;
    const token = signSession(
      { userId: u.userId, email: u.email, displayName: u.displayName, avatarUrl: u.avatarUrl },
      process.env.COOKIE_SECRET!
    );

    res.cookie(sessionCookieName, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      maxAge: 1000 * 60 * 60 * 24 * 14,
    });

    res.redirect(process.env.FRONTEND_ORIGIN + "/lobby");
  }
);

router.post("/logout", (_req, res) => {
  res.clearCookie(sessionCookieName);
  res.json({ ok: true });
});

router.get("/failed", (_req, res) => res.status(401).send("Auth failed"));

export default router;
