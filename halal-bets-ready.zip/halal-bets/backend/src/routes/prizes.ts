import { Router } from "express";
import { db } from "../db/client.js";
import { prizeCampaigns, prizeWinners } from "../db/schema.js";
import { desc, eq } from "drizzle-orm";
import { requireAdmin, requireUser } from "../middleware/auth.js";
import { z } from "zod";
import { topWeekly } from "../services/leaderboard.js";

const router = Router();

router.get("/prizes/campaigns", async (_req, res) => {
  const rows = await db.select().from(prizeCampaigns).orderBy(desc(prizeCampaigns.createdAt)).limit(50);
  res.json({ campaigns: rows });
});

router.get("/prizes/campaigns/:id", async (req, res) => {
  const id = req.params.id;
  const c = await db.select().from(prizeCampaigns).where(eq(prizeCampaigns.id, id)).limit(1);
  if (!c.length) return res.status(404).json({ error: "not_found" });

  const w = await db.select().from(prizeWinners).where(eq(prizeWinners.campaignId, id)).orderBy(prizeWinners.rank);
  res.json({ campaign: c[0], winners: w });
});

const createSchema = z.object({
  name: z.string().min(3).max(120),
  startsAt: z.string().datetime(),
  endsAt: z.string().datetime(),
  prizePoolUsd: z.number().positive(),
  rules: z.string().min(10).max(5000),
});

router.post("/admin/prizes/campaigns", requireUser, requireAdmin, async (req, res) => {
  const parsed = createSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "bad_request", details: parsed.error.flatten() });

  const row = await db.insert(prizeCampaigns).values({
    name: parsed.data.name,
    startsAt: new Date(parsed.data.startsAt),
    endsAt: new Date(parsed.data.endsAt),
    prizePoolUsd: String(parsed.data.prizePoolUsd) as any,
    rules: parsed.data.rules,
  }).returning();

  res.json({ campaign: row[0] });
});

router.post("/admin/prizes/campaigns/:id/close-and-pick-winners", requireUser, requireAdmin, async (req, res) => {
  const id = req.params.id;
  const c = await db.select().from(prizeCampaigns).where(eq(prizeCampaigns.id, id)).limit(1);
  if (!c.length) return res.status(404).json({ error: "not_found" });

  const top = await topWeekly(10);
  const pool = Number(c[0].prizePoolUsd);

  const splits = [0.35, 0.2, 0.12, 0.1, 0.08, 0.05, 0.04, 0.03, 0.02, 0.01];
  const winners = top.slice(0, splits.length).map((x, i) => ({
    campaignId: id,
    userId: x.userId,
    rank: i + 1,
    prizeUsd: (pool * splits[i]).toFixed(2),
  }));

  await db.delete(prizeWinners).where(eq(prizeWinners.campaignId, id));
  if (winners.length) await db.insert(prizeWinners).values(winners as any);

  res.json({ ok: true, winners });
});

export default router;
