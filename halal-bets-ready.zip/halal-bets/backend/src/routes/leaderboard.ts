import { Router } from "express";
import { topDaily, topWeekly } from "../services/leaderboard.js";

const router = Router();

router.get("/leaderboard/daily", async (_req, res) => {
  res.json({ items: await topDaily(50) });
});

router.get("/leaderboard/weekly", async (_req, res) => {
  res.json({ items: await topWeekly(50) });
});

export default router;
