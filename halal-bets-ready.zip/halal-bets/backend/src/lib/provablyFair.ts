import crypto from "crypto";

export function sha256Hex(input: string) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

export function hmacSha256Hex(key: string, msg: string) {
  return crypto.createHmac("sha256", key).update(msg).digest("hex");
}

export function fairFloat(serverSeed: string, clientSeed: string, nonce: number) {
  const hex = hmacSha256Hex(serverSeed, `${clientSeed}:${nonce}`);
  const slice = hex.slice(0, 13);
  const intVal = parseInt(slice, 16);
  return intVal / Math.pow(16, slice.length);
}

export function newServerSeed() {
  return crypto.randomBytes(32).toString("hex");
}
