import Link from "next/link";
import { BACKEND } from "../lib/api";
import { BrandMark } from "./BrandMark";
import { Button } from "./Button";

function Pill({ href, label }: { href: string; label: string }) {
  return (
    <Link
      href={href}
      className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm hover:bg-white/10"
    >
      {label}
    </Link>
  );
}

export function Nav({ authed }: { authed: boolean }) {
  return (
    <div className="sticky top-0 z-10 border-b border-white/10 bg-slate-950/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
        <Link href="/" className="flex items-center gap-3">
          <BrandMark />
          <div className="leading-tight">
            <div className="font-semibold">Halal Bets</div>
            <div className="text-xs text-slate-400">Tokens • Sponsored prizes • No deposits</div>
          </div>
        </Link>

        <div className="flex flex-wrap items-center gap-2">
          {authed ? (
            <>
              <Pill href="/lobby" label="Lobby" />
              <Pill href="/games/slots" label="Slots" />
              <Pill href="/games/roulette" label="Roulette" />
              <Pill href="/wallet" label="Wallet" />
              <Pill href="/leaderboard" label="Leaderboard" />
              <Pill href="/cash-prizes" label="Cash Prizes" />
              <Pill href="/admin" label="Admin" />

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  await fetch(`${BACKEND}/auth/logout`, { method: "POST", credentials: "include" });
                  window.location.href = "/";
                }}
              >
                <Button variant="light" type="submit">Logout</Button>
              </form>
            </>
          ) : (
            <Pill href="/login" label="Login" />
          )}
        </div>
      </div>
    </div>
  );
}
