import { ButtonHTMLAttributes } from "react";

export function Button(props: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "light" }) {
  const variant = props.variant ?? "primary";
  const base = "inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-semibold transition disabled:opacity-60";
  const styles =
    variant === "primary"
      ? "bg-emerald-400 text-slate-950 hover:bg-emerald-300"
      : variant === "light"
      ? "bg-white text-slate-900 hover:bg-slate-200"
      : "border border-white/10 bg-white/5 hover:bg-white/10";
  const { className, variant: _v, ...rest } = props;
  return <button className={`${base} ${styles} ${className ?? ""}`} {...rest} />;
}
