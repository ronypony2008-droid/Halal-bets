import { ReactNode } from "react";
import { Nav } from "./Nav";

export function Layout({ children, authed }: { children: ReactNode; authed: boolean }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Nav authed={authed} />
      <div className="mx-auto max-w-6xl px-4 py-8">{children}</div>
      <footer className="border-t border-white/10 py-6">
        <div className="mx-auto max-w-6xl px-4 text-sm text-slate-400">
          Tokens only. No deposits, no withdrawals. Cash prizes are sponsored/pre-funded campaigns.
        </div>
      </footer>
    </div>
  );
}
