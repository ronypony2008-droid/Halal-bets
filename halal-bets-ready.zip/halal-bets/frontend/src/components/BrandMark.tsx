export function BrandMark() {
  return (
    <div className="grid h-10 w-10 place-items-center rounded-2xl bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-500/30 shadow-glow">
      HB
    </div>
  );
}
