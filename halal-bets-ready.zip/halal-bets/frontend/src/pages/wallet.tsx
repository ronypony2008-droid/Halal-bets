import { useEffect, useState } from "react";
import { apiGet } from "../lib/api";
import { Layout } from "../components/Layout";
import { Card } from "../components/Card";

export default function Wallet() {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    apiGet<any>("/wallet").then(setData).catch(() => (window.location.href = "/login"));
  }, []);

  return (
    <Layout authed={true}>
      <div className="grid gap-5">
        <Card title="Wallet" subtitle="Your token balance and ledger history">
          <div className="rounded-3xl border border-white/10 bg-black/20 px-5 py-4">
            <div className="text-xs text-slate-400">Balance</div>
            <div className="mt-1 text-3xl font-semibold">{data?.balance ?? "…"}</div>
          </div>
        </Card>

        <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <div className="text-lg font-semibold">Recent activity</div>
          <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
            <div className="grid grid-cols-12 bg-black/30 px-4 py-2 text-xs text-slate-400">
              <div className="col-span-6">Time</div>
              <div className="col-span-4">Reason</div>
              <div className="col-span-2 text-right">Delta</div>
            </div>

            {(data?.ledger ?? []).map((x: any) => (
              <div key={x.id} className="grid grid-cols-12 border-t border-white/10 px-4 py-3 text-sm">
                <div className="col-span-6 text-slate-300">{new Date(x.createdAt).toLocaleString()}</div>
                <div className="col-span-4 text-slate-200">{x.reason}</div>
                <div className={`col-span-2 text-right font-semibold ${Number(x.delta) >= 0 ? "text-emerald-300" : "text-rose-300"}`}>
                  {x.delta}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}
