import { useEffect, useState } from "react";
import { apiGet, apiPost } from "../lib/api";
import { Layout } from "../components/Layout";
import { Card } from "../components/Card";
import { Button } from "../components/Button";

export default function Admin() {
  const [msg, setMsg] = useState<string>("");
  const [campaigns, setCampaigns] = useState<any[]>([]);

  const [name, setName] = useState("Weekly Sponsored Cash Prizes");
  const [startsAt, setStartsAt] = useState(() => new Date(Date.now() - 1000 * 60 * 60).toISOString());
  const [endsAt, setEndsAt] = useState(() => new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString());
  const [pool, setPool] = useState<number>(1000);
  const [rules, setRules] = useState(
    "Winners are selected from the weekly leaderboard at campaign close (MVP). Prizes are sponsored/pre-funded."
  );

  async function load() {
    await apiGet<any>("/me"); // verify auth
    const c = await apiGet<any>("/prizes/campaigns");
    setCampaigns(c.campaigns);
  }

  useEffect(() => {
    load().catch(() => (window.location.href = "/login"));
  }, []);

  const input = "w-full rounded-2xl border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500/30";

  return (
    <Layout authed={true}>
      <div className="grid gap-5">
        <Card title="Admin" subtitle="Create prize campaigns and pick winners (email-gated)">
          <div className="text-sm text-slate-300">
            Admin access is controlled by <code className="rounded bg-black/30 px-1">ADMIN_EMAIL</code> in <code className="rounded bg-black/30 px-1">backend/.env</code>.
          </div>

          {msg ? (
            <div className="mt-4 rounded-3xl border border-white/10 bg-white/5 p-3 text-sm text-slate-200">{msg}</div>
          ) : null}
        </Card>

        <div className="grid gap-4 lg:grid-cols-2">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <div className="text-lg font-semibold">Create campaign</div>

            <div className="mt-4 grid gap-3">
              <div>
                <label className="text-xs text-slate-400">Name</label>
                <input className={input} value={name} onChange={(e) => setName(e.target.value)} />
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <label className="text-xs text-slate-400">StartsAt (ISO)</label>
                  <input className={input} value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
                </div>
                <div>
                  <label className="text-xs text-slate-400">EndsAt (ISO)</label>
                  <input className={input} value={endsAt} onChange={(e) => setEndsAt(e.target.value)} />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400">Prize pool (USD)</label>
                <input className={input} type="number" value={pool} onChange={(e) => setPool(Number(e.target.value))} />
              </div>

              <div>
                <label className="text-xs text-slate-400">Rules</label>
                <textarea className={input} rows={4} value={rules} onChange={(e) => setRules(e.target.value)} />
              </div>

              <Button
                onClick={async () => {
                  setMsg("");
                  try {
                    await apiPost<any>("/admin/prizes/campaigns", { name, startsAt, endsAt, prizePoolUsd: pool, rules });
                    setMsg("Campaign created.");
                    await load();
                  } catch {
                    setMsg("Create failed (are you admin?).");
                  }
                }}
              >
                Create
              </Button>
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <div className="text-lg font-semibold">Existing campaigns</div>
            <div className="mt-4 grid gap-3">
              {campaigns.map((c) => (
                <div key={c.id} className="rounded-3xl border border-white/10 bg-black/20 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold">{c.name}</div>
                      <div className="mt-1 text-xs text-slate-400">
                        ${c.prizePoolUsd} • {new Date(c.startsAt).toLocaleString()} → {new Date(c.endsAt).toLocaleString()}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      onClick={async () => {
                        setMsg("");
                        try {
                          await apiPost<any>(`/admin/prizes/campaigns/${c.id}/close-and-pick-winners`, {});
                          setMsg("Winners picked (MVP).");
                        } catch {
                          setMsg("Pick winners failed (are you admin?).");
                        }
                      }}
                    >
                      Close & Pick
                    </Button>
                  </div>
                </div>
              ))}

              {!campaigns.length ? (
                <div className="rounded-3xl border border-white/10 bg-black/20 p-4 text-sm text-slate-300">
                  No campaigns yet.
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
