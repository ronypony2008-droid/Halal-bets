import { useEffect, useState } from "react";
import { apiGet } from "../lib/api";
import { Layout } from "../components/Layout";
import { Card } from "../components/Card";

function Board({ title, items }: { title: string; items: any[] }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <div className="text-lg font-semibold">{title}</div>
      <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
        <div className="grid grid-cols-12 bg-black/30 px-4 py-2 text-xs text-slate-400">
          <div className="col-span-2">Rank</div>
          <div className="col-span-7">User</div>
          <div className="col-span-3 text-right">Score</div>
        </div>

        {items.map((x, idx) => (
          <div key={x.userId} className="grid grid-cols-12 border-t border-white/10 px-4 py-3 text-sm">
            <div className="col-span-2 text-slate-300">#{idx + 1}</div>
            <div className="col-span-7 text-slate-200 truncate">{x.userId}</div>
            <div className="col-span-3 text-right font-semibold text-emerald-300">{x.score}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Leaderboard() {
  const [daily, setDaily] = useState<any[]>([]);
  const [weekly, setWeekly] = useState<any[]>([]);

  useEffect(() => {
    apiGet<any>("/leaderboard/daily").then((r) => setDaily(r.items));
    apiGet<any>("/leaderboard/weekly").then((r) => setWeekly(r.items));
  }, []);

  return (
    <Layout authed={true}>
      <div className="grid gap-5">
        <Card title="Leaderboards" subtitle="MVP score = net token change from games">
          <div className="text-sm text-slate-300">
            In production, you’ll snapshot scores at campaign close for auditability.
          </div>
        </Card>

        <div className="grid gap-4 md:grid-cols-2">
          <Board title="Daily" items={daily} />
          <Board title="Weekly" items={weekly} />
        </div>
      </div>
    </Layout>
  );
}
