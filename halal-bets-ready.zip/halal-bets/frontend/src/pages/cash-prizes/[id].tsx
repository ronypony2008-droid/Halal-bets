import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { apiGet } from "../../lib/api";
import { Layout } from "../../components/Layout";
import { Card } from "../../components/Card";

export default function PrizeCampaign() {
  const router = useRouter();
  const { id } = router.query;
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    if (!id) return;
    apiGet<any>(`/prizes/campaigns/${id}`).then(setData);
  }, [id]);

  const c = data?.campaign;

  return (
    <Layout authed={true}>
      <div className="grid gap-5">
        <Card
          title={c?.name ?? "Campaign"}
          subtitle={c ? `${new Date(c.startsAt).toLocaleString()} → ${new Date(c.endsAt).toLocaleString()}` : "Loading…"}
        >
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-3xl border border-white/10 bg-black/20 px-5 py-4">
              <div className="text-xs text-slate-400">Prize pool</div>
              <div className="mt-1 text-3xl font-semibold text-emerald-300">${c?.prizePoolUsd ?? "…"}</div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-5">
              <div className="text-xs text-slate-400">Rules</div>
              <div className="mt-2 text-sm text-slate-200 whitespace-pre-wrap">{c?.rules ?? "…"}</div>
            </div>
          </div>
        </Card>

        <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <div className="text-lg font-semibold">Winners</div>
          <div className="mt-4 overflow-hidden rounded-2xl border border-white/10">
            <div className="grid grid-cols-12 bg-black/30 px-4 py-2 text-xs text-slate-400">
              <div className="col-span-2">Rank</div>
              <div className="col-span-7">User</div>
              <div className="col-span-3 text-right">Prize</div>
            </div>

            {data?.winners?.length ? data.winners.map((w: any) => (
              <div key={w.id} className="grid grid-cols-12 border-t border-white/10 px-4 py-3 text-sm">
                <div className="col-span-2 text-slate-300">#{w.rank}</div>
                <div className="col-span-7 text-slate-200 truncate">{w.userId}</div>
                <div className="col-span-3 text-right font-semibold text-emerald-300">${w.prizeUsd}</div>
              </div>
            )) : (
              <div className="border-t border-white/10 px-4 py-4 text-sm text-slate-300">
                No winners picked yet.
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
