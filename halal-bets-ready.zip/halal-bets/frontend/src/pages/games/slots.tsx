import { useEffect, useState } from "react";
import { apiGet, apiPost } from "../../lib/api";
import { Layout } from "../../components/Layout";
import { Card } from "../../components/Card";
import { Button } from "../../components/Button";

function randSeed() {
  return Math.random().toString(36).slice(2, 10);
}

export default function Slots() {
  const [balance, setBalance] = useState<number>(0);
  const [wager, setWager] = useState<number>(100);
  const [clientSeed, setClientSeed] = useState<string>(randSeed());
  const [nonce, setNonce] = useState<number>(0);
  const [last, setLast] = useState<any>(null);
  const [err, setErr] = useState<string>("");

  async function load() {
    const w = await apiGet<any>("/wallet");
    setBalance(w.balance);
  }

  useEffect(() => {
    load().catch(() => (window.location.href = "/login"));
  }, []);

  return (
    <Layout authed={true}>
      <div className="grid gap-5">
        <Card title="Slots" subtitle="Spin reels using Tokens (no real money)">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="rounded-3xl border border-white/10 bg-black/20 px-5 py-4">
              <div className="text-xs text-slate-400">Tokens</div>
              <div className="mt-1 text-3xl font-semibold">{balance}</div>
            </div>

            <div className="flex flex-wrap gap-2">
              <div className="grid gap-1">
                <label className="text-xs text-slate-400">Wager</label>
                <input
                  className="w-36 rounded-2xl border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500/30"
                  type="number"
                  value={wager}
                  onChange={(e) => setWager(Number(e.target.value))}
                />
              </div>

              <div className="grid gap-1">
                <label className="text-xs text-slate-400">Client seed</label>
                <input
                  className="w-44 rounded-2xl border border-white/10 bg-black/30 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500/30"
                  value={clientSeed}
                  onChange={(e) => setClientSeed(e.target.value)}
                />
              </div>

              <Button
                onClick={async () => {
                  setErr("");
                  try {
                    const r = await apiPost<any>("/games/slots/spin", { wager, clientSeed, nonce });
                    setNonce(nonce + 3);
                    setLast(r);
                    await load();
                  } catch {
                    setErr("Spin failed. Check your balance or wager limits.");
                  }
                }}
              >
                Spin
              </Button>
            </div>
          </div>

          {err ? (
            <div className="mt-4 rounded-3xl border border-rose-500/20 bg-rose-500/10 p-3 text-sm text-rose-200">
              {err}
            </div>
          ) : null}
        </Card>

        <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <div className="text-lg font-semibold">Result</div>
          <div className="mt-4 rounded-3xl border border-white/10 bg-black/20 p-5">
            {last ? (
              <>
                <div className="text-center text-4xl font-semibold tracking-widest text-emerald-300">
                  {last.result.reels.join("  •  ")}
                </div>
                <div className="mt-3 text-center text-sm text-slate-300">
                  Payout: <span className="font-semibold text-white">{last.result.payout}</span>{" "}
                  (multiplier {last.result.payoutMultiplier})
                </div>
                <div className="mt-4 text-xs text-slate-400">
                  Round ID: <span className="font-mono text-slate-200">{last.roundId}</span>
                </div>
              </>
            ) : (
              <div className="text-sm text-slate-300">Spin to generate a result.</div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
