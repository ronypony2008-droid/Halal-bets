import { Layout } from "../components/Layout";
import { Button } from "../components/Button";
import { BACKEND } from "../lib/api";

export default function Login() {
  return (
    <Layout authed={false}>
      <div className="mx-auto max-w-xl">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <h1 className="text-2xl font-semibold">Sign in</h1>
          <p className="mt-2 text-sm text-slate-300">
            Use Google login. (You’ll enable it by adding OAuth keys in <code className="rounded bg-black/30 px-1">backend/.env</code>.)
          </p>

          <div className="mt-5">
            <a href={`${BACKEND}/auth/google`}>
              <Button className="w-full">Continue with Google</Button>
            </a>
          </div>

          <div className="mt-4 text-xs text-slate-400">
            This product uses Tokens only. No deposits, no withdrawals.
          </div>
        </div>
      </div>
    </Layout>
  );
}
