import { useEffect, useState } from "react";
import Link from "next/link";
import { apiGet } from "../lib/api";
import { Layout } from "../components/Layout";
import { Card } from "../components/Card";

export default function CashPrizes() {
  const [campaigns, setCampaigns] = useState<any[]>([]);

  useEffect(() => {
    apiGet<any>("/prizes/campaigns").then((r) => setCampaigns(r.campaigns));
  }, []);

  return (
    <Layout authed={true}>
      <div className="grid gap-5">
        <Card
          title="Cash Prizes"
          subtitle="Sponsored / pre-funded campaigns (not from player losses)"
        >
          <div className="text-sm text-slate-300">
            Each campaign shows its pool, dates, rules, and winners. This keeps the model transparent and non-gambling.
          </div>
        </Card>

        <div className="grid gap-4">
          {campaigns.map((c) => (
            <Link
              key={c.id}
              href={`/cash-prizes/${c.id}`}
              className="rounded-3xl border border-white/10 bg-white/5 p-6 hover:bg-white/10"
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-lg font-semibold">{c.name}</div>
                  <div className="mt-1 text-sm text-slate-400">
                    {new Date(c.startsAt).toLocaleString()} → {new Date(c.endsAt).toLocaleString()}
                  </div>
                </div>

                <div className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-right">
                  <div className="text-xs text-slate-400">Prize pool</div>
                  <div className="text-xl font-semibold text-emerald-300">${c.prizePoolUsd}</div>
                </div>
              </div>
            </Link>
          ))}
          {!campaigns.length ? (
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-sm text-slate-300">
              No campaigns yet. Ask Admin to create one.
            </div>
          ) : null}
        </div>
      </div>
    </Layout>
  );
}
