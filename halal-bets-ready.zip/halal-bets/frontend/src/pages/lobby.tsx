import { useEffect, useState } from "react";
import Link from "next/link";
import { apiGet, apiPost } from "../lib/api";
import { Layout } from "../components/Layout";
import { Card } from "../components/Card";
import { Button } from "../components/Button";

export default function Lobby() {
  const [me, setMe] = useState<any>(null);
  const [balance, setBalance] = useState<number>(0);
  const [msg, setMsg] = useState<string>("");

  async function load() {
    const m = await apiGet<any>("/me");
    setMe(m.user);
    const w = await apiGet<any>("/wallet");
    setBalance(w.balance);
  }

  useEffect(() => {
    load().catch(() => (window.location.href = "/login"));
  }, []);

  return (
    <Layout authed={true}>
      <div className="grid gap-5">
        <Card
          title={`Welcome${me?.displayName ? `, ${me.displayName}` : ""}`}
          subtitle="Your tokens, bonus, and quick actions"
        >
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="rounded-3xl border border-white/10 bg-black/20 px-5 py-4">
              <div className="text-xs text-slate-400">Tokens</div>
              <div className="mt-1 text-3xl font-semibold">{balance}</div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                onClick={async () => {
                  setMsg("");
                  try {
                    const r = await apiPost<any>("/daily-bonus", {});
                    setMsg(`Daily bonus claimed: +${r.amount} Tokens`);
                    await load();
                  } catch {
                    setMsg("Daily bonus already claimed (try again later).");
                  }
                }}
              >
                Claim Daily Bonus
              </Button>
              <Link href="/cash-prizes">
                <Button variant="ghost">Cash Prizes</Button>
              </Link>
            </div>
          </div>

          {msg ? (
            <div className="mt-4 rounded-3xl border border-white/10 bg-white/5 p-3 text-sm text-slate-200">
              {msg}
            </div>
          ) : null}
        </Card>

        <div className="grid gap-4 md:grid-cols-2">
          <Link href="/games/slots" className="rounded-3xl border border-white/10 bg-white/5 p-6 hover:bg-white/10">
            <div className="text-xs text-slate-400">Game</div>
            <div className="mt-1 text-xl font-semibold">Slots</div>
            <div className="mt-2 text-sm text-slate-300">Spin reels and win Tokens.</div>
          </Link>

          <Link href="/games/roulette" className="rounded-3xl border border-white/10 bg-white/5 p-6 hover:bg-white/10">
            <div className="text-xs text-slate-400">Game</div>
            <div className="mt-1 text-xl font-semibold">Roulette</div>
            <div className="mt-2 text-sm text-slate-300">Bet on color or number (Tokens).</div>
          </Link>
        </div>
      </div>
    </Layout>
  );
}
