import Link from "next/link";
import { Layout } from "../components/Layout";
import { Button } from "../components/Button";

export default function Home() {
  return (
    <Layout authed={false}>
      <div className="grid gap-8 lg:grid-cols-2">
        <div className="space-y-5">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-3 py-1 text-xs text-emerald-200">
            Premium • Clean • Tokens-only
          </div>

          <h1 className="text-4xl font-semibold tracking-tight md:text-5xl">
            Halal Bets
          </h1>

          <p className="text-slate-300">
            A fintech-clean, casino-style experience using internal <span className="font-semibold text-white">Tokens</span>.
            No deposits, no withdrawals. <span className="font-semibold text-white">Cash prizes</span> are sponsored / pre-funded.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <Link href="/login">
              <Button>Login with Google</Button>
            </Link>
            <Link href="/cash-prizes">
              <Button variant="ghost">View Cash Prizes</Button>
            </Link>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-xs text-slate-400">Play</div>
              <div className="mt-1 font-semibold">Slots & Roulette</div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-xs text-slate-400">Earn</div>
              <div className="mt-1 font-semibold">Daily bonus</div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-xs text-slate-400">Compete</div>
              <div className="mt-1 font-semibold">Leaderboards</div>
            </div>
          </div>
        </div>

        <div className="rounded-[28px] border border-white/10 bg-gradient-to-b from-white/10 to-white/5 p-6">
          <div className="text-sm text-slate-300">How it stays halal</div>
          <ul className="mt-4 space-y-2 text-slate-200">
            <li className="flex gap-2"><span className="text-emerald-300">✓</span> Tokens are internal only</li>
            <li className="flex gap-2"><span className="text-emerald-300">✓</span> No deposits / withdrawals</li>
            <li className="flex gap-2"><span className="text-emerald-300">✓</span> Cash prizes are sponsored</li>
          </ul>

          <div className="mt-6 rounded-3xl border border-white/10 bg-black/20 p-4">
            <div className="text-xs text-slate-400">Transparency</div>
            <div className="mt-1 text-sm text-slate-200">
              Prize campaigns show pool amount, dates, and winners. Nothing comes from player losses.
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
