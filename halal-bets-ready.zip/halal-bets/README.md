# Halal Bets — ready-to-run MVP (Premium / Fintech clean)

**Important:** This is *casino-style UX* but **NOT gambling**:
- No deposits / withdrawals
- No wagering real money
- Internal **Tokens** ledger only
- **Cash prizes** are *sponsored / pre-funded campaigns* (admin-created), not pooled from player losses

## Stack
- Frontend: Next.js (TypeScript) + Tailwind CSS (premium dark UI)
- Backend: Express (TypeScript)
- DB: PostgreSQL + Drizzle ORM
- Cache: Redis (leaderboards)
- Auth: Google OAuth (Passport) + signed cookie session

---

## Run locally

### 1) Start Postgres + Redis
From repo root:
```bash
docker compose up -d
```

### 2) Backend
```bash
cd backend
cp .env.example .env
npm i
npm run db:migrate
npm run dev
```
Backend: http://localhost:4000

### 3) Frontend
```bash
cd ../frontend
cp .env.example .env.local
npm i
npm run dev
```
Frontend: http://localhost:3000

---

## Enable Google login
Create an OAuth client in Google Cloud Console (Web app):

Authorized redirect URI:
- `http://localhost:4000/auth/google/callback`

Then set in `backend/.env`:
- `GOOGLE_CLIENT_ID=...`
- `GOOGLE_CLIENT_SECRET=...`

Admin access:
- `ADMIN_EMAIL=your_google_email@example.com`

---

## Pages
- `/` Landing
- `/login`
- `/lobby`
- `/games/slots`
- `/games/roulette`
- `/wallet`
- `/leaderboard`
- `/cash-prizes`
- `/cash-prizes/[id]`
- `/admin`

---

## Notes
This is an MVP. For production (10M MAU) you’ll want:
- Cloudflare Turnstile / bot protection
- rate limiting + device fingerprinting
- leaderboard snapshots + audit logs
- KYC only for *winners* (cash prize payouts)
